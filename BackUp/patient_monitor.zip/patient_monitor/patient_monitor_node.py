#!/usr/bin/env python

import rospy
import numpy as np
from geometry_msgs.msg import Vector3 as vec

def VelCallback(data):
  
  pass

def patient_monitor():
  # Initialize the ROS node
  rospy.init_node('patient_monitor_node', anonymous=True)

  # initialize the node
  keypoints_vel_sub_topic = "/keypoints_vel"
  retreat_direction_pub_topic = "/retreat_direction"

  keypoints_vel_sub = rospy.Subscriber(keypoints_vel_sub_topic, vec, VelCallback)
  retreat_direction_pub = rospy.Publisher(retreat_direction_pub_topic, vec, queue_size=10)

  rospy.spin()
  
if __name__ == "main":
  patient_monitor()